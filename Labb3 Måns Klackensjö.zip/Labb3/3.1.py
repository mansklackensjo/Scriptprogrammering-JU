def absolute(number):
    if number < 0:
        return number * -1
    
    else:
        return number
    
print(absolute(3))
print(absolute(-5))
print(absolute(-2))
print(absolute(0))